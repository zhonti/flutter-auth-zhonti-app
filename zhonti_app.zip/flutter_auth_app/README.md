# Авторизация + Firebase (Flutter)

Приложение из трёх экранов:

- **Авторизация** — вход по email и паролю через Firebase Authentication;
- **Регистрация** — форма (email, пароль, ФИО, возраст, количество котов, пол, любимый язык, о себе), создаёт аккаунт в Firebase;
- **Главный экран** — приветствие и кнопка выхода.

## Запуск

1. Создайте проект на https://console.firebase.google.com и включите
   **Authentication → Sign-in method → Email/Password**.
2. В папке проекта выполните:

   ```
   flutter create .
   flutter pub get
   ```

   Затем впишите данные своего проекта Firebase в начало `lib/main.dart` (константа `firebaseOptions`).
3. Запустите:

   ```
   flutter run
   ```

Зарегистрированные пользователи видны в консоли Firebase: **Authentication → Users**.
