import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

// ================= НАСТРОЙКИ FIREBASE =================
// Вставьте сюда данные своего проекта:
// Firebase Console → Project settings → Your apps → SDK setup and configuration
const firebaseOptions = FirebaseOptions(
  apiKey: 'YOUR_API_KEY',
  appId: 'YOUR_APP_ID',
  messagingSenderId: 'YOUR_SENDER_ID',
  projectId: 'YOUR_PROJECT_ID',
  authDomain: 'YOUR_PROJECT_ID.firebaseapp.com',
);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: firebaseOptions);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Авторизация',
      theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
      // Если пользователь уже вошёл — сразу главный экран
      home: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
                body: Center(child: CircularProgressIndicator()));
          }
          return snapshot.hasData ? const HomePage() : const LoginPage();
        },
      ),
    );
  }
}

// Перевод ошибок Firebase на русский
String authError(FirebaseAuthException e) {
  switch (e.code) {
    case 'invalid-email':
      return 'Неверный формат email';
    case 'user-not-found':
    case 'wrong-password':
    case 'invalid-credential':
      return 'Неверный email или пароль';
    case 'email-already-in-use':
      return 'Такой email уже зарегистрирован';
    case 'weak-password':
      return 'Пароль слишком простой (минимум 6 символов)';
    default:
      return 'Ошибка: ${e.message}';
  }
}

void showMsg(BuildContext context, String text) =>
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

// ================= ЭКРАН АВТОРИЗАЦИИ =================
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _loading = false;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    setState(() => _loading = true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _email.text.trim(),
        password: _password.text,
      );
      // StreamBuilder сам откроет HomePage
    } on FirebaseAuthException catch (e) {
      if (mounted) showMsg(context, authError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(32),
          child: Column(
            children: [
              const Text('Авторизация', style: TextStyle(fontSize: 28)),
              const SizedBox(height: 32),
              TextField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                    labelText: 'Email', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _password,
                obscureText: true,
                decoration: const InputDecoration(
                    labelText: 'Пароль', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 24),
              _loading
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: _login, child: const Text('Войти')),
              TextButton(
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const RegisterPage())),
                child: const Text('Зарегистрироваться'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ================= ЭКРАН РЕГИСТРАЦИИ =================
class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _name = TextEditingController();
  final _about = TextEditingController();
  bool _isAdult = false;
  int _cats = 0;
  String _gender = 'М';
  String? _language;
  bool _loading = false;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _name.dispose();
    _about.dispose();
    super.dispose();
  }

  Future<void> _register() async {
    if (_name.text.trim().isEmpty) {
      showMsg(context, 'Введите ФИО');
      return;
    }
    setState(() => _loading = true);
    try {
      final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _email.text.trim(),
        password: _password.text,
      );
      await cred.user?.updateDisplayName(_name.text.trim());
      if (mounted) Navigator.pop(context); // StreamBuilder откроет HomePage
    } on FirebaseAuthException catch (e) {
      if (mounted) showMsg(context, authError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Регистрация на IT-фестиваль')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _email,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
                labelText: 'Email', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _password,
            obscureText: true,
            decoration: const InputDecoration(
                labelText: 'Пароль (минимум 6 символов)',
                border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _name,
            decoration: const InputDecoration(
                labelText: 'ФИО', border: OutlineInputBorder()),
          ),
          CheckboxListTile(
            title: const Text('Мне исполнилось 14 лет'),
            value: _isAdult,
            onChanged: (v) => setState(() => _isAdult = v ?? false),
            controlAffinity: ListTileControlAffinity.leading,
          ),
          Row(children: [
            const Expanded(child: Text('Количество котов:')),
            IconButton(
              icon: const Icon(Icons.remove_circle_outline),
              onPressed: _cats > 0 ? () => setState(() => _cats--) : null,
            ),
            Text('$_cats', style: const TextStyle(fontSize: 18)),
            IconButton(
              icon: const Icon(Icons.add_circle_outline),
              onPressed: () => setState(() => _cats++),
            ),
          ]),
          Row(children: [
            const Text('Пол:'),
            Radio<String>(
                value: 'М',
                groupValue: _gender,
                onChanged: (v) => setState(() => _gender = v!)),
            const Text('М'),
            Radio<String>(
                value: 'Ж',
                groupValue: _gender,
                onChanged: (v) => setState(() => _gender = v!)),
            const Text('Ж'),
          ]),
          DropdownButtonFormField<String>(
            value: _language,
            decoration: const InputDecoration(
                labelText: 'Любимый язык программирования',
                border: OutlineInputBorder()),
            items: ['Dart', 'Python', 'Java', 'Kotlin', 'Swift']
                .map((l) => DropdownMenuItem(value: l, child: Text(l)))
                .toList(),
            onChanged: (v) => setState(() => _language = v),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _about,
            maxLines: 4,
            decoration: const InputDecoration(
                labelText: 'Немного о себе',
                alignLabelWithHint: true,
                border: OutlineInputBorder()),
          ),
          const SizedBox(height: 20),
          Center(
            child: _loading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _register,
                    child: const Text('Зарегистрироваться')),
          ),
        ],
      ),
    );
  }
}

// ================= ГЛАВНЫЙ ЭКРАН =================
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Главный экран'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Выйти',
            onPressed: () => FirebaseAuth.instance.signOut(),
          ),
        ],
      ),
      body: Center(
        child: Text(
          'Добро пожаловать, ${user?.displayName ?? user?.email ?? ''}!',
          style: const TextStyle(fontSize: 20),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
